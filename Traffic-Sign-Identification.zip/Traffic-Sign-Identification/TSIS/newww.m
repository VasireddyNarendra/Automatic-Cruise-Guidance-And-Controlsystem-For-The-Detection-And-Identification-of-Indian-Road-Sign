tStart=tic;
pause(5);
tElapsed=toc(tStart)