Traffic-Sign-Identification-System
==================================
Traffic Sign Identification System (TSIS) is used to
regulate traffic signs, warn a driver, and command or prohibit
certain actions. Fast real-time and robust automatic traffic sign
detection and recognition can support and disburden the driver
and significantly increase driving safety and comfort. Automatic
recognition of traffic signs is also important for an automated
intelligent driving vehicle or for driver assistance systems. This
project presents a study to recognize traffic sign patterns using
Neural Network technique.Whole process consists of two phases
Detection and Recognition Of Traffic Signs.
